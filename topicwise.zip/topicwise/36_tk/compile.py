#!/usr/bin/python 
tuple = ( 'abcd', 786 , 2.23, 'john', 70.2 ) 
list = [ 'abcd', 786 , 2.23, 'john', 70.2 ] 
#tuple[2] = 1000        # Invalid syntax with tuple 
list[2] = 1000            # Valid syntax with list
