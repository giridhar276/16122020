


class x:
    def m1(self,a):
        print "one parameter of m1 of class x"
    def m2(self,a,b):
        print "two paramters of m1 of class x"


x1 = x()

x1.m1(100,200)


x1.m1(100)
