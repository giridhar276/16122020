def personInfo():
    print("hello ... I am person")
