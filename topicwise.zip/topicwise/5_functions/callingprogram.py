import function1

function1.printme(20,30)
