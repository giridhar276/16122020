
display = lambda x,y : x+y


val = display("perl","programming")
print(val)



'''
syntax:

lambda values : expression
'''
