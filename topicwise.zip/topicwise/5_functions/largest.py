
def max_of_three(*vartup):
    largest = max(list(vartup))
    return(largest)
    



lar =max_of_three(34,45,439898)
print("Largest  : ", lar)
