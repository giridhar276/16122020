class Robot:
    def __init__(self,name1,name2):
        self.name1 = name1
        self.name2 = name2
        print("Hello" + self.name1 + self.name2)
        
 
    

x = Robot("python","Perl")
#x.SayHello("python","Perl")
