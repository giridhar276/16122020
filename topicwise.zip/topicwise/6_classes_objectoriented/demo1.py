class Robot:
    def SayHello(self):
        print("Hello")
        

x = Robot()
x.SayHello()







