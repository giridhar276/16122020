
book = {"chap1":10 ,"chap2":20 ,"chap3":30 ,"chap1":1000}
print(book)
# accessing individual values
print(book['chap1'])  #10
print(book['chap2'])  #20


# iterating the dictionary
for i in book:
    print(i)       # will display KEY
    print(book[i]) # will display VALUE
    







