alist = [10,20,30,40,50,60,70]

for val in alist:
    print(val)

print("end of for loop")




name = "python"
for char in name:
    print(char)


print("out of for loop")