adict = {"chap1":10 ,"chap2":20}

print(adict)
print(adict.keys())    # ONLY keys
print(adict.values())  # ONLY values


print(adict.items())  # dictionary in list format

print(adict["chap1"])
#print(adict["chap5"])
print(adict.get("chap5"))

bdict = {"chap3":30 , "chap4":40}

# combine both the dictionaries : adict and bdict
final = {**adict, **bdict}
print(final)

## will return both key,value
for key,value in adict.items():
    print(key,value)
    
    
    