alist = [10,20,30,40,50,60,70]

print(alist[0]) # 10
print(alist[1]) # 20
print(alist[2]) # 30

blist = ["python","kafka","ruby"]
clist = [10,20,5.65,"java"]

print(alist)
print("list elements are ", alist)


alist[0] = 100
print("After replacing" , alist)

final_list = [alist,blist,clist]
print("Elements are ", final_list)


print(alist[0:3])
print(alist[2:4])
print(alist[::-1])










