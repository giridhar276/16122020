#### tuple 
atup = (45,67,34)
btup = ("java","oracle","mysql")
ctup = (56,7.89,"python")

print(atup[0])



#atup[0] = 1000
#print("After replacing :", atup)



for lang in btup:
    print(lang)
    
    