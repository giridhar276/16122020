

# simple line comment
print("python programming")


# numbers
val = 10
print(val)
print("Value is ", val)


aval = 4.566
print("Decimal value is", aval)

