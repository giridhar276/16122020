alist = [45,34,67,34,23,67,7,4]

alist.append(900)   # adding one single object at the END only
print("After appending :", alist)
alist.append(90)
print("After appending :", alist)

alist.extend([6,4,3,45,23])   # passing multiple objects
print("After extending :", alist)

getcount = alist.count(10)
print("10 is repeated for ", getcount , "times")

# insert(where to insert, what to insert)
alist.insert(0, 10)
print("After inserting : ", alist)
alist.insert(3, 100)
print("After inserting : ", alist)

alist.pop()  # remove the last value
print("After pop:", alist)

alist.pop(0)  # remove the value at index 0
print("After pop:", alist)

alist.pop(5)  # remove the value at index 5
print("After pop:", alist)

alist.sort()                  # ascending order by default
print("After sorting", alist)
alist.sort(reverse=True)   # descending order
print("After sorting(descending)", alist)

alist.reverse()
print("After reversing:", alist)

