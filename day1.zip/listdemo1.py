
atup = (10,20,30,40)

# step1: convert to the list
alist = list(atup)

# make some change
alist[2] = 3000

# step2: recovert back to tuple
atup = tuple(alist)

print(atup)


# converting string to list
name = "python"
print(list(name))