aset =  {10,10,10,20,30,45,6,3,5,5454,3}


print(aset)
print(aset)