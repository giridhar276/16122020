name = "python programming"
print(name.capitalize())
print(name.center(40,"*"))
print(name.count('p'))
print(name.replace('python', 'perl'))
print(name.upper())
print(name.lower())
print(name.split(" "))
print(name.startswith('p'))
print(name.startswith('q'))
print(name.endswith('g'))

val = 10
if val <= 10 :
    print("value is less than 10")
    print("Inside if only")
    print("Still inside if only")
print("Outside if condition")


if name.isupper() :
    print("String is upper")
else:
    print("string is lower")
    
    
if name.startswith("z"):
    print("String is starting with z")
else:
    print("String is starting with p")    


if name.endswith("g"):
    print("String is python programming")
else:
    print("String is something else")




print(name)
print(len(name))

alist = [10,20,30]
print(len(alist))



# template : which is reused again and again
name = "I love {} and {}"  
print(name.format("python", "perl"))
print(name.format("python", "java"))
print(name.format("hadoop", "java"))



name = " python "
print(len(name))

name = name.strip()   #remove spaces at both the ends
print(len(name))






















