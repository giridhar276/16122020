name = 'python programming'

#name[0] = 'z'
#print(name)


bname = "python programming"
cname = """unix shell scripting"""
print(name)
print("Language is ", bname)
# string[start:stop:step]
print(name)
print(name[0])
print(name[1])
print(name[4])
print(name[0:5])
print(name[3:5])
print(name[2:6])
print(name[0:9])
print(name[0:])
print(name[::])
print(name[:])
print(name[0:17:2])
print(name[0:17:3])
print(name[1:17:2])
print(name[0::])   # everything
print(name[-1])
print(name[-3:-1])
print(name[::-2])  # reverse of the string





