import time
import sys
from pathlib import Path
try:
    filename = time.strftime("%d_%b_%Y.txt")
    print(filename)
    Path(filename).touch()
except Exception as err:
    print(err)
    print(sys.exc_info())