

# used for API 
# used for web services
# used for downloading web page
import requests                # for reading the webpage
from bs4 import BeautifulSoup  # web scraping

#step1:
response = requests.get("https://www.techworldguru.com")
#response.text  contains complete html page#
if response.status_code == 200 :
    #print(response.text)
    soup = BeautifulSoup(response.text, 'html.parser')
    for link in soup.find_all('a'):
        print(link.get('href'))
else:
    print("status code is not 200")