

from openpyxl import Workbook
import time

wb = Workbook()

ws = wb.active

for val in range(1,101):
    ws.append([val])

filename = time.strftime("%d_%b_%Y.xlsx")

wb.save(filename)