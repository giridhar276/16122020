import os
os.

# task 5

try:
    with open("realestate.csv") as fobj:
        for line in fobj:
            line = line.strip()
            line = line.replace('SACRAMENTO' , 'BANGALORE')
            print(line)
except Exception as err:
    print("Unknown exception")
    print(err)
    
    
## writing the output to new file   
try:
    with open("realestate.csv") as fobj:
        with open("BANGALORE.csv","w") as fwrite:
            for line in fobj:
                line = line.strip()
                line = line.replace('SACRAMENTO' , 'BANGALORE')
                fwrite.write(line + "\n")
except Exception as err:
    print("Unknown exception")
    print(err)