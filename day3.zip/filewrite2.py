# using context manager
# closing is not required
# file is closed automatically


#
with open("lang.txt","w") as fobj:
    fobj.write("python programming\n")
    fobj.write("spark programming\n")

    
    
# write a program to write all the numbers from 1 to 10 the file 
# line by line

with open("numbers.txt","w") as fobj:
    for val in range(1,11):
        fobj.write(str(val) + "\n")
        
        





