import os
import csv
from openpyxl import Workbook
import time
try:
    wb = Workbook()
    ws = wb.active
    
    filename = "realestate.csv"
    # validating whether the .csv file is existing or not
    if os.path.exists(filename):
        with open(filename,"r") as fobj:
            #converting from file object to csv object
            reader = csv.reader(fobj)
            # reading each line from csv file
            for line in reader:
                # appending to excel file
                ws.append(line)
                
        # creating string with today's timestamp
        excelname = time.strftime("realestate_%d_%b_%Y.xlsx")
        wb.save(excelname)
    else:
        print("Input file(csv file) doesnt exist")  
    
    #os.remove(excelname)
        
except Exception as err:
    print(err)        
        