##### using csv library
#2. Write a Python program to read realestate.csv and display ONLY street and city columns.
import csv
try:
    with open("realestate.csv") as fobj:
        reader = csv.reader(fobj)
        for line in reader:
            street = line[0]
            city = line[1]
            print("Street :",street)
            print("City   :",city)
            print("------------")

except Exception as err:
    print("Unknown exception")
    print(err)

####
#3. Write a Python program to read realestate.csv and display all the UNIQUE cities and the count of unique cities.
import csv

cityset = set()
try:
    with open("realestate.csv") as fobj:
        reader = csv.reader(fobj)
        for line in reader:
            city = line[1]
            cityset.add(city)
        ## displaying all the cities  
        for city in cityset:
            print(city)
except Exception as err:
    print("Unknown exception")
    print(err)