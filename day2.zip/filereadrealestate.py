

try:
    with open("realestate.csv") as fobj:
        for line in fobj:
            line = line.strip()
            print(line)
            print("------------")

except Exception as err:
    print("Unknown exception")
    print(err)




##### using csv library
import csv
try:
    with open("realestate.csv") as fobj:
        reader = csv.reader(fobj)
        for line in reader:

            print(line)

except Exception as err:
    print("Unknown exception")
    print(err)
