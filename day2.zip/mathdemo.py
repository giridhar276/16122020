
from math import sin,cos,tan
print(sin(2))
print(cos(1))



