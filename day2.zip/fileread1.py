
#reading line by line
#
with open("employees.txt","r") as fobj:
    for line in fobj:
        line = line.strip()  # remove whitespaces if any
        print(line)
       
# display only names
with open("employees.txt","r") as fobj:
    for line in fobj:
        line = line.strip()  # remove whitespaces if any
        output = line.split(",")
        print(output[0])    
        
        
## using csv library
import csv
with open("employees.txt","r") as fobj:
    # convert file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print(line)