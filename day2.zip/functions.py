print(tuple(range(1,10)))

print(list(range(2,5)))

print(list(range(2,10,2)))

print(list(range(1,10,2)))

for val in range(1,10):
    print(val)
    
    
# reading input from keyboard    
name = input("Enter any string :")
print(name)


alist = [10,20,30,6]

print(max(alist))
print(min(alist))
print(sum(alist))

print(id(alist))  # identity of an object
print(id(10))



print(type(10))

alist = [10,203]
print(type(alist))

print(isinstance(alist, str))










