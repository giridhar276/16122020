
# using readlines()
with open("employees.txt","r") as fobj:
    print(fobj.readlines())
    
    
with open("employees.txt","r") as fobj:
    print(fobj.read())