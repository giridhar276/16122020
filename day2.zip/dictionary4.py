info = {
  "engines": {
    "composer": "^0.20.0"
  },
  "name": "perishable-network",
  "version": "0.2.6",
  "description": "Shipping Perishable Goods Business Network",
  "networkImage": "https://hyperledger.github.io/composer-sample-networks/packages/perishable-network/networkimage.svg",
  "networkImageanimated": "https://hyperledger.github.io/composer-sample-networks/packages/perishable-network/networkimageanimated.svg",
  "scripts": {
    "prepublish": "mkdirp ./dist && composer archive create  --sourceType dir --sourceName . -a ./dist/perishable-network.bna",
    "pretest": "npm run lint",
    "lint": "eslint .",
    "postlint": "npm run licchk",
    "licchk": "license-check-and-add",
    "postlicchk": "npm run doc",
    "doc": "jsdoc --pedantic --recurse -c jsdoc.json",
    "test": "mocha -t 0 --recursive",
    "deploy": "./scripts/deploy.sh"
  }
}

for key,value in info.items():
    print(key,value)


for key,value in info.items():
    if isinstance(value,str):
        print(key, ":", value)
    elif isinstance(value,dict):
        for subkey,subvalue in value.items():
            print(subkey,":",subvalue)