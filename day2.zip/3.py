
## question 3
name = "I love python programming and enjoy python language"

'''
Output:
I  : 1 time
love : 1 time
python : 2 times
programming : 1 time
and  : 1 time
enjoy : 1 time
language : 1 time
'''
## question 3
name = "python python programming"
output = name.split(" ")
print(output)
for item in set(output):
    print(item.ljust(15), output.count(item), "time")
    
    
