## write operation
##  fobj is called as file handler or file object or file cursor


filename = input("Enter any filename :")
fobj = open(filename,"w")
fobj.write("python programming\n")
fobj.write("spark programming\n")
fobj.close()


## creating the file in different path
fobj = open("D:\\languages.txt","w")
fobj.write("python programming\n")
fobj.write("spark programming\n")
fobj.close()


## creating the file in different path
fobj = open("C:\\Users\\gsripath\\Desktop\\languages.txt","w")
fobj.write("python programming\n")
fobj.write("spark programming\n")
fobj.close()


fobj = open("C:\\Users\\gsripath\\Desktop\\languages.txt","w")  # OR
fobj = open("C:/Users/gsripath/Desktop/languages.txt","w")      # OR
fobj = open(r"C:\Users\gsripath\Desktop\languages.txt","w")     # raw




