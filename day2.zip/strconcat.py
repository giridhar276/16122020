
## str concat
#### Objects should be of same type

print(str(1) + "hello")


first = "python"
second = "programming"

final = first + " " +  second
print(final)


alist = [10,20,30]
blist = [50,60,70]

finalist = alist + blist
print(finalist)


atup = (10,20,30)
btup = (45,33)

finaltup = atup + btup
print(finaltup)


#in
string = "python programming"
string.

#method1
getcount = string.count("python")
print(getcount)

# method2
if "python" in string:
    print("exists")
else:
    print("doesnt exist")
    
    
    
alist = [10,20,30,40]

if 10 in alist:
    print("exist")
else:
    print("doesnt exist")
    
getcount = alist.count(10)
if getcount > 0 :
    print("exists")
else:
    print("doesn't exist")






    
    













