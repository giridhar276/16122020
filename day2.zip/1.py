

# question1
string = "python programming"


output = list(string)
for item in set(output):
    print(item.ljust(15), output.count(item), "time")
    
    
    
# task 22
# task 23
# task 24
# task 32
# task 38
# task 39
# task 41
# task 42